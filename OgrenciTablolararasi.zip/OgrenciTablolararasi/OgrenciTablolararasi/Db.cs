﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciTablolararasi
{
    internal class Db
    {
        public static string dbname = "Data Source=HOSAF-WINDOWS;Initial Catalog=ogrenciler;Integrated Security=True";
    }
}
